import time
import random

# We don't need 'google.generativeai' anymore because we are simulating it!

def audit_certificate(certificate_text):
    """
    SIMULATES the AI Auditor.
    It checks for keywords locally instead of calling Google.
    """
    print(f"\nPAGE: Analyzing document: '{certificate_text[:30]}...'")
    print("🤖 AI Processing: Checking compliance standards...")
    
    # Simulate "Thinking" time (makes it look real)
    time.sleep(2) 
    
    # --- THE LOGIC (The Mock Brain) ---
    certificate_text_lower = certificate_text.lower()
    
    # Rule 1: Check for "ISO 14001"
    has_standard = "iso 14001" in certificate_text_lower
    
    # Rule 2: Check for "2025"
    has_year = "2025" in certificate_text_lower
    
    # Return the result just like the Real AI would
    if has_standard and has_year:
        return "✅ RESULT: APPROVED\n   Reason: Valid ISO standard and current year found."
    else:
        missing = []
        if not has_standard: missing.append("Missing ISO 14001")
        if not has_year: missing.append("Year 2025 not found")
        return f"❌ RESULT: REJECTED\n   Reason: {', '.join(missing)}."

# --- TEST ZONE ---
if __name__ == "__main__":
    
    # Test 1: Real Certificate
    print("--- 🟢 TEST 1: REAL CERTIFICATE ---")
    good_cert = "This certifies SteelCo is ISO 14001 compliant for the year 2025."
    print(audit_certificate(good_cert))
    
    print("\n" + "="*30 + "\n")
    
    # Test 2: Fake Certificate
    print("--- 🔴 TEST 2: FAKE CERTIFICATE ---")
    bad_cert = "We are a very green company, trust us! We love nature."
    print(audit_certificate(bad_cert))