import hashlib
import json
from time import time

class Blockchain:
    def __init__(self):
        self.chain = []
        # FIX: We manually set previous_hash='1' so it doesn't look for a non-existent block
        self.new_block(proof=100, data_input="Genesis Block - System Start", previous_hash='1')

    def new_block(self, proof, data_input, previous_hash=None):
        """
        Creates a new Block in the Blockchain
        """
        # If previous_hash is NOT provided, calculate it from the last block
        # If it IS provided (like for Genesis), use that instead.
        if previous_hash is None:
            previous_hash = self.hash(self.chain[-1])

        block = {
            'index': len(self.chain) + 1,
            'timestamp': time(),
            'proof': proof,
            'previous_hash': previous_hash,
            'data': data_input 
        }
        self.chain.append(block)
        return block

    @staticmethod
    def hash(block):
        """
        Creates the digital fingerprint (Hash)
        """
        # Sort keys ensures consistent hashes
        block_string = json.dumps(block, sort_keys=True).encode()
        return hashlib.sha256(block_string).hexdigest()