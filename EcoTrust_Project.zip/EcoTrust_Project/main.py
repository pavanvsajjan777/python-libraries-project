# --- IMPORTS ---
from auditor import audit_certificate   # The AI Brain
from blockchain import Blockchain       # The Ledger (We just fixed this!)
import json
import time

# --- SETUP ---
print("⚙️  System Starting...")
print("   > Initializing Blockchain Ledger...")
eco_ledger = Blockchain()
print("   > Blockchain Ready.\n")

def process_supplier_upload(supplier_name, certificate_text):
    print(f"\n🚀 NEW UPLOAD RECEIVED: {supplier_name}")
    print("-" * 40)
    
    # 1. AI AUDIT
    print("   1️⃣  Sending document to AI Auditor...")
    time.sleep(1) 
    ai_decision = audit_certificate(certificate_text)
    
    # 2. BLOCKCHAIN RECORDING
    print("   2️⃣  Recording result on Blockchain...")
    block_data = f"Supplier: {supplier_name} | {ai_decision}"
    
    # We let the Blockchain calculate the previous hash automatically now
    new_block = eco_ledger.new_block(proof=123, data_input=block_data)
    
    print(f"   ✅ SUCCESS: Block #{new_block['index']} mined.")
    print(f"      Hash: {eco_ledger.hash(new_block)}")

# --- THE LIVE SIMULATION ---
if __name__ == "__main__":
    print("--- 🌍 ECOTRUST LIVE DEMO STARTING ---")
    
    # 1. Tesla (Good)
    process_supplier_upload(
        "Tesla Gigafactory", 
        "This certifies Tesla Gigafactory is ISO 14001 compliant for 2025."
    )
    
    # 2. Lazy Co (Bad)
    process_supplier_upload(
        "Lazy Manufacturing Inc", 
        "We are very good, trust us."
    )
    
    # 3. Samsung (Good)
    process_supplier_upload(
        "Samsung Batteries", 
        "This certifies Samsung Batteries is ISO 14001 compliant for the year 2025."
    )

    # --- FINAL REPORT ---
    print("\n\n" + "="*50)
    print("📜 FINAL IMMUTABLE LEDGER")
    print("="*50)
    print(json.dumps(eco_ledger.chain, indent=4))